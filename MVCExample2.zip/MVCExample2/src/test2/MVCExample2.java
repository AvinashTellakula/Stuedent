package test2;


public class MVCExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teacher model = new Teacher("A1","abhi");
		TeacherView view = new TeacherView();
		TeacherController con = new TeacherController(model,view);
		con.displayteacher();
		con.setteacherName("ABC");
		System.out.println("After Updation: \n");
		con.displayteacher();

	}

}
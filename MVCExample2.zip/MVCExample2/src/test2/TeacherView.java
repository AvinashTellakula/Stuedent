package test2;

public class TeacherView {
	public void updateview(String id, String name) {
		System.out.println("Roll Number: " + id);
		System.out.println("Name: " + name);
	}

}
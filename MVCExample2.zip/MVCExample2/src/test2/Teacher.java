package test2;

public class Teacher {
private String roll_number,name;
	
	public Teacher(String id, String name) {
		this.roll_number = id;
		this.name = name;
	}
	
	public String getRollNumber() {
		return this.roll_number;
	}
	
	public void setRollNumber(String id) {
		this.roll_number = id;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
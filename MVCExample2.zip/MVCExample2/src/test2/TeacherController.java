package test2;


public class TeacherController {
	private Teacher model;
	private TeacherView view;
	public TeacherController(Teacher model, TeacherView view) {
		this.model = model;
		this.view = view;
	}
	public String getteachertRollNumber() {
		return model.getRollNumber();
	}
	
	public String getteacherName() {
		return model.getName();
	}
	
	public void setteacherName(String name) {
		model.setName(name);
	}
	
	public void displayteacher() {
		view.updateview(model.getRollNumber(), model.getName());
	}
	
	

}
package test;

public class MVCExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student model = new Student("A1","Sriram");
		StudentView view = new StudentView();
		StudentController con = new StudentController(model,view);
		con.displayStudent();
		con.setStudentName("ABC");
		System.out.println("After Updation: \n");
		con.displayStudent();
	}

}

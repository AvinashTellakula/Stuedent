package test;

public class StudentView {
	
	public void updateView(String rno, String name) {
		System.out.println("Roll Number: " + rno);
		System.out.println("Name: " + name);
	}
	
}

package test;

public class Student {
	private String roll_number,name;
	
	public Student(String rno, String name) {
		this.roll_number = rno;
		this.name = name;
	}
	
	public String getRollNumber() {
		return this.roll_number;
	}
	
	public void setRollNumber(String rno) {
		this.roll_number = rno;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

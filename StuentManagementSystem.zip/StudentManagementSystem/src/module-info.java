/**
 * 
 */
/**
 * @author Keerthi Akanksha
 *
 */
module StudentManagementSystem {
	requires java.sql;
}